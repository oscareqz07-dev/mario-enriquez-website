MARIO ENRIQUEZ BUSINESS WEBSITE

Files:
- index.html — complete responsive website
- images/ — supplied project photos

The site is static and ready to publish on a web host. The quote form opens the visitor's email app and prepares a message to 78marioenriquez@gmail.com.

Business phone: 214-524-8661
Business email: 78marioenriquez@gmail.com
Service area: Dallas-Fort Worth and surrounding areas, including Weatherford, Aledo, Granbury, Hillsboro, Cresson, Azle, and nearby communities.
